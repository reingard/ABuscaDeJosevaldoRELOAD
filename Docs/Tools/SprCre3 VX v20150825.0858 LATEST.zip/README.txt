Send any problems and feedback to jensen_305@yahoo.com.
 
Special Thanks:
Axerax at RPGRevolution for making the background graphic for Sprite Creator 3
Holder at RPGRevolution for your beard images.
Ying for the Orcs
Famitsu for providing most of the base images.
Zac Ray for all your images that you are currently still adding to.
 
USING THE PROGRAM.
You must have the Java JRE installed on your computer. 

Application Version:
If you double click the SprCre3.jar and it runs you don't need to do anything. Otherwise
-right click > open as > navigate to where Java is installed 
(Usually "c:\Program Files (x86)\Java\" or "C:\Program Files\Java")
Open the JRE folder (No JRE folder? Java JRE is not installed. Go install it.)
Open the bin folder
find javaw.exe and click ok.
Select the check box to always run as selected and you'll not be able to double click the jar and run it.

Web Applet Version:
run index.html. 
Accept the script and you're all set.
